package main

import . "goplus/src/Object"

func SaveModel( service IService) IService {
	service.Save()
	return service
}

//IService  代言   UserService 和 ProdService
func main()  {

	 NewProdService().Save().List().Save().List()
}