package Object

type IService interface {
	Save() IService
	List() IService
}
