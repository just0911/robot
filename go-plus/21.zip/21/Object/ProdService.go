package Object

import "log"

type ProdService struct {

}

func NewProdService() *ProdService  {
	return &ProdService{}
}
//保存入库
func(this *ProdService) Save() IService{
	log.Println("商品保存入库成功")
	return this
}
func(this *ProdService) List() IService{
	log.Println("商品列表获取")
	return this
}