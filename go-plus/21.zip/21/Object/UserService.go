package Object

import "log"

type UserService struct {

}

func NewUserService() *UserService  {
	return &UserService{}
}
//保存入库
func(this *UserService) Save() IService{
     log.Println("用户保存入库成功")
     return this
}
func(this *UserService) List() IService{
	log.Println("用户列表获取")
	return this
}