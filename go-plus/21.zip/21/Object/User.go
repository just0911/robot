package Object

type User struct {
	Id int
	Name string
	Sex byte
}
// 有选择性的对ID 进行赋值
func NewUser(fs ...UserAttrFunc) *User  {
	 u:= new(User)
	 UserAttrFuncs(fs).apply(u)
	 return u
}






