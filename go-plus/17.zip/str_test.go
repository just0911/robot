package mytest

import (
	"goplus/src/Utils"
	"testing"
)
func Test_str(t *testing.T)  {
	str:=Utils.Join("abc","bcd","def")
	t.Log(str)
}
func TestJoin(t *testing.T) {
	type args struct {
		strs []string
	}
	tests := []struct {
		name string
		args args
		want string
	}{
		{"t1",args{[]string{"a","b"}},"ab"},
		{"t2",args{[]string{"a","b","c"}},"aaaaa"},
		{"t3",args{[]string{"a","b","c","d"}},"abcd"},
	}
	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			if got := Utils.Join(tt.args.strs...); got != tt.want {
				t.Errorf("Join() = %v, want %v", got, tt.want)
			}
		})
	}
}
