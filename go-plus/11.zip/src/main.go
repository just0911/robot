package main

import (
	"fmt"
	"goplus/src/Map"
)
// map chan slice
func change( u Map.User)  {
	 u["id"]="404"
}
func main()  {


	  u:=Map.NewUser()

	  u["id"]="101"
	  u["name"]="shenyi"
	change(u)
	fmt.Println(u)
}