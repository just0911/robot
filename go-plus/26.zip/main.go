package main

import (
	"fmt"
	"reflect"
)

type User struct {
	UserId int
	UserName string
}
func Map2Struct(m map[string]interface{},u interface{})  {
    v:=reflect.ValueOf(u)
    if v.Kind()==reflect.Ptr{
		v=v.Elem()
		if v.Kind()!=reflect.Struct{
			panic("must struct")
		}
		findFromMap:= func(key string ) interface {}{
			for k,v:=range m{
				if k==key{
					return v
				}
			}
			return nil
		}
		for i:=0;i<v.NumField();i++{
			get_value:=findFromMap(v.Type().Field(i).Name)
			if get_value!=nil && reflect.ValueOf(get_value).Kind()==v.Field(i).Kind(){
				v.Field(i).Set(reflect.ValueOf(get_value))
			}
		}
	}else{
		panic("must ptr")
	}
}
func main()  {
    u:=&User{}
	m:=map[string]interface{}{
		"id":123,
		"UserId":101,
		"UserName":"shenyi",
		"age":19,
	}
	Map2Struct(m,u)
	fmt.Print(u)







}