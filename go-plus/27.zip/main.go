package main

import (
	"fmt"
	"reflect"
)

type User struct {
	UserId int `name:"uid" bcd:"3456"`
	UserName string
}
func Map2Struct(m map[string]interface{},u interface{})  {
    v:=reflect.ValueOf(u)
    if v.Kind()==reflect.Ptr{
		v=v.Elem()
		if v.Kind()!=reflect.Struct{
			panic("must struct")
		}
		findFromMap:= func(key string,nameTag string ) interface {}{
			for k,v:=range m{
				if k==key || k==nameTag {
					return v
				}
			}
			return nil
		}
		for i:=0;i<v.NumField();i++{
			get_value:=findFromMap(v.Type().Field(i).Name,v.Type().Field(i).Tag.Get("name"))
			if get_value!=nil && reflect.ValueOf(get_value).Kind()==v.Field(i).Kind(){
				v.Field(i).Set(reflect.ValueOf(get_value))
			}
		}
	}else{
		panic("must ptr")
	}
}
func main()  {
    u:=&User{}
	m:=map[string]interface{}{
		"id":123,
		"uid":101,
		"UserName":"shenyi",
		"age":19,
	}
	Map2Struct(m,u)
	fmt.Print(u)








}