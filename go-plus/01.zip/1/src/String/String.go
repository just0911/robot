package String

type String string  //我自己的 String

func From(str string) String{
	return String(str)
}