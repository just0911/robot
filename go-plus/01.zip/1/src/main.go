package main

import (
	"fmt"
	"goplus/src/String"
)

func main()  {
	s:=String.From("abc")
	fmt.Println(s)
}