package main

import (
	"fmt"
	"goplus/src/String"
)

func main()  {
	str:=String.From("abcde")


	str.Each(func(item string) {
		  fmt.Println(item)
	})


}