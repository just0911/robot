package Utils

import (
	"bytes"
	"strings"
)

type Spider interface {
	GetBody() string
}
//累加字符串
func Join(strs ...string)  string  {
	ret:=""
	for _,s:=range strs{
		ret+=s
	}
	return ret
}
func Join2(strs ...string)  string  {
	return strings.Join(strs,"")
}
func Join3(strs ...string)  string  {
	var bf bytes.Buffer
	for _,s:=range strs{
		bf.WriteString(s)
	}
	return bf.String()
}

