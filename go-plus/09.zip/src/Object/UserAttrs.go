package Object
type UserAttrFunc func(u *User)

func WithUserID(id int) UserAttrFunc  {
	return func(u *User) {
		u.Id=id
	}
}
func WithUserName(name string) UserAttrFunc  {
	return func(u *User) {
		u.Name=name
	}
}