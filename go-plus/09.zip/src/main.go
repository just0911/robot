package main

import (
	"fmt"
	"goplus/src/Object"
)

func main()  {


	//技术：两“害”取其轻
    u:=Object.NewUser(
		Object.WithUserName("shenyi"),
    	   Object.WithUserID(105),
    	)
    fmt.Println(u)

}