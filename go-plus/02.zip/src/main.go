package main

import (
	"fmt"
	"goplus/src/String"
)

func main()  {
	s:=String.FromInt(123)

	fmt.Println(s,s.Len())


}