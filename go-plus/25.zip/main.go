package main

import (
	"fmt"
	"reflect"
)

type User struct {
	UserId int
	UserName string
}

func main()  {
    u:=&User{}
    t:=reflect.ValueOf(u)
    if t.Kind()==reflect.Ptr{
		t=t.Elem()
	}
	values:=[]interface{}{12,"shenyi"}

    for i:=0;i<t.NumField();i++{
    	if t.Field(i).Kind()==reflect.ValueOf(values[i]).Kind(){
    		t.Field(i).Set(reflect.ValueOf(values[i]))
		}
	}
    fmt.Println(u)




}