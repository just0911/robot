package Utils

//累加字符串
func Join(strs ...string)  string  {
	ret:=""
	for _,s:=range strs{
		ret+=s
	}
	return ret
}