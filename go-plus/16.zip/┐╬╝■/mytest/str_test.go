package mytest

import (
	"goplus/src/Utils"
	"testing"
)

func Test_str(t *testing.T)  {
	str:=Utils.Join("abc","bcd","def")
	t.Log(str)
}