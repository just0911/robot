package main

import (
	"fmt"
	"reflect"
)

type User struct {
	UserId int
	UserName string
}

func main()  {
    u:=User{}

    t:=reflect.TypeOf(u)
    t=t.Elem() //把t变成了指针指向的变量
    for i:=0;i<t.NumField();i++{
    	fmt.Println(t.Field(i).Name,t.Field(i).Type)
	}

}