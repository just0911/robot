package Object

import "log"

type UserService struct {

}

func NewUserService() *UserService  {
	return &UserService{}
}
//保存入库
func(this *UserService) Save(){
     log.Println("用户保存入库成功")
}
