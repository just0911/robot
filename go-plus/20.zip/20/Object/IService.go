package Object

type IService interface {
	Save()
}
