package main

import . "goplus/src/Object"

func main()  {
	 var service  IService= NewProdService()
	 service.Save()
}