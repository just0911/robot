package main

import (
	"fmt"
	"goplus/src/Map"
	"sort"
)

func main()  {
	 u1:=Map.NewUser()
     u1.With("id",101).
	 	With("name","shenyi").
		With("age",19)

	u2:=Map.NewUser()
	u2.With("id",102).
		With("name","lisi").
		With("age",21)

	u3:=Map.NewUser()
	u3.With("id",101).
		With("name","zhangsan").
		With("age",17)

   users:=[]Map.User{}
   users=append(users,u1,u2,u3)
// a  ,b     c=人类   c.(a)
   sort.Slice(users, func(i, j int) bool {
	  age1:= users[i]["age"].(int)  //断言功能  专针对 interface
	  age2:= users[j]["age"].(int)
	  return  age1>age2
   })

	fmt.Println(users)




}