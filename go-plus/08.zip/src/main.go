package main

import (
	"fmt"
	"goplus/src/Object"
)

func main()  {

    u:=Object.NewUser(
    	   Object.WithUserID(120),
    	)
    fmt.Println(u)

}