package Object

type User struct {
	Id,Sex int
	Name string
}
// 有选择性的对ID 进行赋值
func NewUser(f func(u *User)) *User  {
	 u:= new(User)
	 f(u)
	 return u
}
func WithUserID(id int) func(u *User)  {
	return func(u *User) {
		u.Id=id
	}
}


