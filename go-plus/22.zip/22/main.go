package main

import . "goplus/src/Object"


//IService  代言   UserService 和 ProdService
func main()  {

	//user:=NewUser(
	//	WithUserName("shenyi"),
	//	WithUserSex(1),
	//	)
	 NewUserService().Save("123")

}