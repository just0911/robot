package Object

import "log"

type UserService struct {

}

func NewUserService() *UserService  {
	return &UserService{}
}
//保存入库
//断言：针对 interface进行 类型判断
func(this *UserService) Save(data interface{}) IService{

	if user,ok:=data.(*User);ok{

		log.Printf("%v",user.Name)
		log.Println("用户保存入库成功")
	}else{
		log.Fatal("用户参数错误")
	}

     return this
}
func(this *UserService) List() IService{
	log.Println("用户列表获取")
	return this
}