package main

import (
	"fmt"
	"reflect"
)

type User struct {
	UserId int
	UserName string
}

func main()  {
    u:=&User{101,"shenyi"}

    t:=reflect.ValueOf(u)
    if t.Kind()==reflect.Ptr{
		t=t.Elem()
	}
    for i:=0;i<t.NumField();i++{
			fmt.Println(t.Field(i).Interface())

	}

}