package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"io/ioutil"
	"log"
	"mypro/gsrc/pbfiles"
	"net/http"

	"strings"
)
func checkError(err error){
	if err!=nil{
		panic(err)
	}
}
//根据ca 和证书  获取 tlsConfig配置对象
func getTLSConfig() *tls.Config{
	cert,err:=tls.LoadX509KeyPair("res/clientgrpc.crt","res/clientgrpc.key")
	if err!=nil{
		log.Fatal(err)
	}
	certPool := x509.NewCertPool()
	ca, err:= ioutil.ReadFile("res/JtthinkCA.crt")
	if err!=nil{
		log.Fatal(err)
	}
	certPool.AppendCertsFromPEM(ca)

	return  &tls.Config{
		Certificates: []tls.Certificate{cert},
		ServerName: "grpc.jtthink.com",
		RootCAs:      certPool,
	}

}
//用grpc客户端测试
func testByGrpClient(){
	client,err:=grpc.DialContext(context.Background(),
		"grpc.jtthink.com:30090",
		grpc.WithTransportCredentials(credentials.NewTLS(getTLSConfig())))

	if err != nil {
		log.Fatal(err)
	}

	if err!=nil{
		log.Fatal(err)
	}
	rsp:=&pbfiles.ProdResponse{}

	err=client.Invoke(context.Background(),
		"/ProdService/GetProd",
		&pbfiles.ProdRequest{ProdId:123},rsp)
	if err!=nil{
		log.Fatal(err)
	}
	fmt.Println(rsp.Result)
}
//使用https客户端测试(带证书)
func testByHttpsClient(){
	 req,err:=http.NewRequest("POST","https://grpc.jtthink.com:30090/detail",
	 	strings.NewReader(`{"prod_id":567}`))
	req.Header.Set("Origin","http://localhost")
	checkError(err)
	tr := &http.Transport{
		 TLSClientConfig:  getTLSConfig(),
	}
	 client:=http.Client{
		 Transport:tr,
	 }
	 rsp,err:=client.Do(req)
	fmt.Println(rsp)
	 checkError(err)
	 defer rsp.Body.Close()
	 b,err:=ioutil.ReadAll(rsp.Body)
	 checkError(err)
	 fmt.Println(string(b))

}
//使用http客户端测试(跳过验证)
func testByHttpClient(){
	req,err:=http.NewRequest("POST","https://http.grpc.jtthink.com:30090/detail",
		strings.NewReader(`{"prod_id":789}`))
	checkError(err)
	tr := &http.Transport{
		TLSClientConfig:  &tls.Config{InsecureSkipVerify:true},
	}
	client:=http.Client{
		Transport:tr,
	}
	rsp,err:=client.Do(req)
	fmt.Println(rsp)
	checkError(err)
	defer rsp.Body.Close()
	b,err:=ioutil.ReadAll(rsp.Body)
	checkError(err)
	fmt.Println(string(b))

}
func main() {
      //testByHttpsClient()
      testByGrpClient()
	//testByHttpClient()


}


