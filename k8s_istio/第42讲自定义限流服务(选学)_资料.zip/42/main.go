package main

import (
	"context"
	pb "github.com/envoyproxy/go-control-plane/envoy/service/ratelimit/v3"
	"google.golang.org/grpc"
	"log"
	"net"
	"time"
)
type MyServer struct {
}
func NewMyServer() *MyServer {
	return &MyServer{}
}
func (s *MyServer) ShouldRateLimit(ctx context.Context,
	request *pb.RateLimitRequest) (*pb.RateLimitResponse, error) {
	var overallCode pb.RateLimitResponse_Code
	if time.Now().Unix()%2==0{
		log.Println("限流")
		overallCode=pb.RateLimitResponse_OVER_LIMIT
	}else{
		log.Println("OK")
		overallCode=pb.RateLimitResponse_OK
	}
	response := &pb.RateLimitResponse{OverallCode: overallCode}
	return response, nil
}
func main() {
	lis, err := net.Listen("tcp", ":8080")
	if err != nil {
		log.Fatal(err)
	}
	s := grpc.NewServer()
	pb.RegisterRateLimitServiceServer(s,NewMyServer())
	if err := s.Serve(lis); err != nil {
		log.Fatal(err)
	}
}
