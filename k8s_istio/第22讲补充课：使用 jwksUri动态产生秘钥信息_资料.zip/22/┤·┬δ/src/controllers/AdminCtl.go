package controllers

import (
	"github.com/gin-gonic/gin"
	"github.com/shenyisyn/goft-gin/goft"
)

type AdminCtl struct{}
func NewAdminCtl() *AdminCtl{
  return &AdminCtl{}
}
func(*AdminCtl)  Name() string{
	 return "AdminCtl"
}
func(*AdminCtl) AdminInfo(c *gin.Context) goft.Json{
	return gin.H{"message":"这是管理员才能看的数据"}
}
func(*AdminCtl) PostAdminInfo(c *gin.Context) goft.Json{
	return gin.H{"message":"这是超级管理才能改的数据"}
}
func(this *AdminCtl)  Build(goft *goft.Goft){
	goft.Handle("GET","/admin",this.AdminInfo)
	goft.Handle("POST","/admin",this.AdminInfo)
}