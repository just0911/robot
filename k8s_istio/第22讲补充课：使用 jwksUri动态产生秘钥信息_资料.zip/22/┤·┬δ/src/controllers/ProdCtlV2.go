package controllers

import (
	"github.com/gin-gonic/gin"
	"github.com/shenyisyn/goft-gin/goft"
	"mypro/src/models"
	"time"
)

type ProdCtlV2 struct{}
func NewProdCtlV2() *ProdCtlV2{
  return &ProdCtlV2{}
}
func(*ProdCtlV2)  Name() string{
	 return "ProdCtl"
}
func(*ProdCtlV2) Detail(c *gin.Context) goft.Json{
	if c.Query("err")!=""{
		c.Set(goft.HTTP_STATUS,503)
		panic(gin.H{"version":"v2","result":"503 error"})
	}
	if c.Query("delay")!=""{
		time.Sleep(time.Second*3)
		panic(gin.H{"version":"v2","result":"我故意延迟了"})
	}
	id:=c.Param("id")
	prod:=models.MockProdDetail(id)
	prod.Reviews=models.CallReview(prod.Id)
	return gin.H{"version":"v2","result":prod}
}
func(this *ProdCtlV2)  Build(goft *goft.Goft){
	goft.Handle("GET","/prods/:id",this.Detail)
}