<template>
  <div >

  </div>
</template>

<script>
  import {ProdServiceClient} from "./../grpcweb/prod_service_grpc_web_pb"
  import { ProdRequest } from '../grpcweb/prod_model_pb.js'

  export default {
    data(){
      return {

      }
    },
  created() {
    const client = new ProdServiceClient('http://vue.grpc.jtthink.com:30090');
    const req=new ProdRequest()
    req.setProdId(789)
    const metadata = {"Content-Type": "application/grpc-web-text"};
    client.getProd(req,metadata,(err,rsp)=>{
      if (err) {
        console.log(err.message);
      } else {
        console.log(rsp.getResult());
      }
    })

  }

}
</script>
