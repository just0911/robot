package main

import (
	"github.com/gin-gonic/gin"
	"github.com/shenyisyn/goft-gin/goft"
	"mypro/src/controllers"
	"net/http"
)
func crosv2() gin.HandlerFunc {
	return func(c *gin.Context) {
		method := c.Request.Method
		if method == "OPTIONS" {
			c.AbortWithStatus(http.StatusNoContent)
		}else{
			c.Next()
		}

	}
}
func main() {
	goft.Ignite(crosv2()).Mount("",
		controllers.NewProdCtlV2(),
		controllers.NewAdminCtl(),
		).Launch()
}