package main

import (
	"context"
	"crypto/tls"
	"crypto/x509"
	"fmt"
	"google.golang.org/grpc"
	"google.golang.org/grpc/credentials"
	"io/ioutil"
	"log"
	"mypro/gsrc/pbfiles"
)
func main() {

	//client,err:=grpc.DialContext(context.Background(),":8080",grpc.WithInsecure())
	//client,err:=grpc.DialContext(context.Background(),
	//	"grpc.jtthink.com:30090",grpc.WithInsecure())
	//creds, err := credentials.NewClientTLSFromFile("res/grpc.jtthink.com.crt",
	//	"grpc.jtthink.com")
	cert,err:=tls.LoadX509KeyPair("res/clientgrpc.crt","res/clientgrpc.key")
	if err!=nil{
		log.Fatal(err)
	}
	certPool := x509.NewCertPool()
	ca, err:= ioutil.ReadFile("res/JtthinkCA.crt")
	if err!=nil{
		log.Fatal(err)
	}
	certPool.AppendCertsFromPEM(ca)
	creds:=credentials.NewTLS(&tls.Config{
		Certificates: []tls.Certificate{cert},
		ServerName: "grpc.jtthink.com",
		RootCAs:      certPool,
	})
	client,err:=grpc.DialContext(context.Background(),
		"grpc.jtthink.com:30090",
		grpc.WithTransportCredentials(creds))

	if err != nil {
		log.Fatal(err)
	}

	if err!=nil{
		log.Fatal(err)
	}
	rsp:=&pbfiles.ProdResponse{}
	err=client.Invoke(context.Background(),
		"/ProdService/GetProd",
		&pbfiles.ProdRequest{ProdId:123},rsp)
	if err!=nil{
		log.Fatal(err)
	}
	fmt.Println(rsp.Result)




}


